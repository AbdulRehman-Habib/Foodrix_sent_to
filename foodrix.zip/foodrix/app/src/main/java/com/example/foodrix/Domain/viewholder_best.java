package com.example.foodrix.Domain;

public class viewholder_best {
        int product_img;
        String title;
        double rating ;
        double time;

        public viewholder_best(int product_img ,String title, double rating , double time){

            this. product_img= product_img;
            this.title = title;
            this.rating= rating;
            this.time=time;
        }



}
